#import <Cordova/CDVPlugin.h>

@interface OnFidoBridge : CDVPlugin {
}

- (void)init: (CDVInvokedUrlCommand *)command;

@end
